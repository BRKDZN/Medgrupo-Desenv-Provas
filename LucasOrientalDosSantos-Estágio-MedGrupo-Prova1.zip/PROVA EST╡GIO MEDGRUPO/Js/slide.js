var intervalo = 1000;


function slide1(){
    document.getElementById("banner").src="./img/imgslides/pic1.png";
    setTimeout("slide2()", intervalo);

}

function slide2(){
    document.getElementById("banner").src="./img/imgslides/pic2.png";
    setTimeout("slide3()", intervalo);
}

function slide3(){
    document.getElementById("banner").src="./img/imgslides/pic3.png";
    setTimeout("slide1()", intervalo);
}